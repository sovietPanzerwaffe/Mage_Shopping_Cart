<?php
class Web4Pro_News_Block_Adminhtml_Authors_Renderer_AuthorsRenderer extends Mage_Adminhtml_Block_Widget_Grid_Column_Renderer_Abstract
{
	
    public function render(Varien_Object $row)
    {

			
		$authors = Mage::getSingleton('news/authors')
					->getCollection();
		$authors->addFieldToFilter('name',$row->getData('author'));
		$authorId = $authors->getFirstItem()->getData('author_id');
		$authorName = $authors->getFirstItem()->getData('name');
		
		$url = $this->getUrl('*/authors/edit', array('id' => $authorId)); 
        $value =  $row->getData($this->getColumn()->getIndex());
		return '<a href="'.$url.'">'.$authorName.'</a>';
    }
}
?>
